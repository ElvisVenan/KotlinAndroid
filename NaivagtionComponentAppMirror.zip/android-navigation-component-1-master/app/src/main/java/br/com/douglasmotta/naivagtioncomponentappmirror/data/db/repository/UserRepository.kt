package br.com.douglasmotta.naivagtioncomponentappmirror.data.db.repository

import br.com.douglasmotta.naivagtioncomponentappmirror.model.User
import br.com.douglasmotta.naivagtioncomponentappmirror.ui.registration.RegistrationViewParams
import java.util.*

interface UserRepository {

    fun createUser(registrationViewParams: RegistrationViewParams)

    fun getUser(id: Long): User

    fun login(username: String, password: String):Long
}