package br.com.douglasmotta.naivagtioncomponentappmirror.ui.registration

data class RegistrationViewParams(
    val name: String ="",
    val username: String ="",
    val bio: String ="",
    val password: String =""
)
