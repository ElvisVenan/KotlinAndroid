package br.com.douglasmotta.naivagtioncomponentappmirror.model

data class User (
        private val id: String,
        private val name: String,
        private val bio: String
)