package com.example.recyclerview

class Note(val title: String,
           val description: String) {

}