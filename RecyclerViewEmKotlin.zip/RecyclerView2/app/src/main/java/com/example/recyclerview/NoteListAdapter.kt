package com.example.recyclerview

import android.content.Context
import android.provider.ContactsContract
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Adapter
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class NoteListAdapter(private val notes : List<Note>,
                      private val context:Context) : RecyclerView.Adapter<NoteListAdapter.ViewHolder>() {
    //Trazer informaçoes da View
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title = itemView.findViewById<TextView>(R.id.note_item_title)
        val description = itemView.findViewById<TextView>(R.id.note_item_description)


    }

    //Inflar o Layout que queremos usar de modelo
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.activity_note_list, parent, false)
        return ViewHolder(view)
    }

    //Passar os dados a serem exibidos
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val note = notes[position]
        holder?.let {
            it.title.text = note.title
            it.description.text = note.description

        }


    }
    //Configura as posições
    override fun getItemCount(): Int {
        return notes.size
    }
}
